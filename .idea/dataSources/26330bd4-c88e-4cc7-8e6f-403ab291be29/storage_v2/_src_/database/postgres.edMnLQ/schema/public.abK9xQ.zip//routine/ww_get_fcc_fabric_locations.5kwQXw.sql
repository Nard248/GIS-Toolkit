create function ww_get_fcc_fabric_locations(user_id integer, user_auth_key text, state_abbreviations text[], county_fips_codes text[], provider_ids bigint[], tech_codes integer[], max_downloads integer[], max_uploads integer[], br_codes integer[])
    returns TABLE("FccLocationId" integer, "CompleteStAddress" character varying, "City" character varying, "State" character varying, "Zip" character varying, "Plus4" character varying, "UnitCount" integer, "BbServicableLocation" boolean, "BuildingType" character varying, "FCCBusinessResidentialCode" character varying, "LandUse" character varying, "Confidence" integer, "ProviderId" bigint, "ProviderFrn" integer, "Provider" character varying, "TechnologyCode" integer, "Technology" character varying, "DLSpeed" integer, "ULSpeed" integer, "LowLatency" boolean, "County" character varying, "Fips" character varying, "CensusBlock2010" character varying, "CensusBlock2020" character varying, "H39" character varying, "Latitude" numeric, "Longitude" numeric, "Source" character varying, "SourceYear" integer)
    language plpgsql
as
$$
declare
   bus_res_code text[];
   companyid integer;
begin

	    if (1 = any(br_codes))  then		
			bus_res_code := bus_res_code || array['R', 'X'];
		end if;

		if (2 = any(br_codes)) then
			bus_res_code := bus_res_code || array['R'];
		end if;

		if (3 = any(br_codes)) then
			bus_res_code := bus_res_code || array['B', 'X'];
		end if;

		if (4 = any(br_codes)) then
			bus_res_code := bus_res_code || array['B'];
		end if;
		
		select company_id into companyid From public."Users" Where "UserID" = user_id and auth_key = user_auth_key;
		
        if found then
        
		CREATE TEMP TABLE temp_us_fabric_locations(			
			fcc_location_id integer,
			complete_st_address character varying(150),
			city character varying(100),
			state_abbr character varying(2),
			zip character varying(5),
			plus4 character varying(4),
			unit_count integer,
			bb_servicable_location boolean,
			building_type character varying(20),
			business_residential_code character varying(50),
			land_use character varying(20),
			confidence integer,
			provider_id bigint,
			provider_frn integer,
			brand_name character varying(100),
			technology_code integer,
			technology character varying(50),
			max_advertised_download_speed integer,
			max_advertised_upload_speed integer,
			low_latency boolean,
			county_2020 character varying(100),
			fips_2020 character varying(5),
			block_code_2010 character varying(15),
			block_code_2020 character varying(15),
			h3_9 character varying(50),
			lat numeric,
			lon numeric,
			source character varying(20),
			source_year integer
 	    );
		
    insert into temp_us_fabric_locations 
		select distinct fcf.fcc_location_id,  fcf.complete_st_address,  fcf.city, fcf.state_abbr, 
			fcf.zip, fcf.plus4, fcf.unit_count, fcf.bb_servicable_location, fcf.building_type,
			fcf.business_residential_code, fcf.land_use, fcf.confidence, fcf.provider_id,
			fcf.provider_frn, fcf.brand_name, fcf.technology_code, fcf.technology,
			fcf.max_advertised_download_speed, fcf.max_advertised_upload_speed, fcf.low_latency,				
			fcf.county_2020, fcf.fips_2020,	fcf.block_code_2010, fcf.block_code_2020, 
			fcf.h3_9, fcf.lat, fcf.lon, fcf.source, fcf.source_year
 		FROM us_fcc_joined_harvested_fabric_locations fcf
		WHERE (fcf.state_abbr = ANY(state_abbreviations) OR ('') = ANY(state_abbreviations)) 
			AND (fcf.fips_2020 = ANY(county_fips_codes) OR ('') = ANY(county_fips_codes)) 
			AND (fcf.provider_id = ANY(provider_ids) OR (-1) = ANY(provider_ids)) 
			AND (fcf.technology_code = ANY(tech_codes) OR (-1) = ANY(tech_codes))
			AND (fcf.max_down_id = ANY(max_downloads) OR (-1) = ANY(max_downloads))
			AND (fcf.max_up_id = ANY(max_uploads) OR (-1) = ANY(max_uploads))
			AND (fcf.business_residential_code = ANY(bus_res_code) OR (-1) = ANY(br_codes));
		
	
		   
		   return query 
		SELECT DISTINCT ON (ffl.fcc_location_id)
			ffl.fcc_location_id AS "FccLocationId", 
			ffl.complete_st_address AS "CompleteStAddress", 
			ffl.city As "City",
			ffl.state_abbr AS "State", 
			ffl.zip As "Zip", 
			ffl.plus4 As "Plus4",
			ffl.unit_count As "UnitCount",
			ffl.bb_servicable_location As "BbServicableLocation",
			ffl.building_type As "BuildingType",
			ffl.business_residential_code As "FCCBusinessResidentialCode",
			ffl.land_use As "LandUse",
			ffl.confidence As "Confidence",			
			ffl.provider_id As "ProviderId",
			ffl.provider_frn As "ProviderFrn",
			ffl.brand_name As "Provider",
			ffl.technology_code As "TechnologyCode",
			ffl.technology As "Technology",
			ffl.max_advertised_download_speed As "DLSpeed",
			ffl.max_advertised_upload_speed As "ULSpeed",
			ffl.low_latency	As "LowLatency",				
			ffl.county_2020 As "County",
			ffl.fips_2020 As "Fips",			
			ffl.block_code_2010 As "CensusBlock2010", 
			ffl.block_code_2020 As "CensusBlock2020", 
			ffl.h3_9 As "H39",
			ffl.lat As "Latitude",
			ffl.lon As "Longitude", 
			ffl.source  As "Source",
			ffl.source_year As "SourceYear"
 		FROM temp_us_fabric_locations ffl;
		
	else 
	return;
	
end if; 			
end;

$$;

alter function ww_get_fcc_fabric_locations(integer, text, text[], text[], bigint[], integer[], integer[], integer[], integer[]) owner to postgresqlwireless2020;

